<?php
define ( "TRANSLATION_BLOG2TWITTER_ADMIN_HEADLINE", "Einstellungen von blog2twitter" );
define ( "TRANSLATION_TWITTER_CONSUMER_KEY", "Twitter Consumer Key" );
define ( "TRANSLATION_TWITTER_CONSUMER_SECRET", "Twitter Consumer Secret" );
define ( "TRANSLATION_TWITTER_ACCESS_TOKEN", "Twitter Access Token" );
define ( "TRANSLATION_TWITTER_ACCESS_TOKEN_SECRET", "Twitter Access Token Secret" );
define ( "TRANSLATION_BLOG2TWITTER_WORKS", "Es funktioniert!" );
define ( "TRANSLATION_BLOG2TWITTER_STATUS", "blog2twitter Status" );
