<?php
define ( "TRANSLATION_BLOG2TWITTER_ADMIN_HEADLINE", "Settings of blog2twitter" );
define ( "TRANSLATION_TWITTER_CONSUMER_KEY", "Twitter Consumer Key" );
define ( "TRANSLATION_TWITTER_CONSUMER_SECRET", "Twitter Consumer Secret" );
define ( "TRANSLATION_TWITTER_ACCESS_TOKEN", "Twitter Access Token" );
define ( "TRANSLATION_TWITTER_ACCESS_TOKEN_SECRET", "Twitter Access Token Secret" );
define ( "TRANSLATION_BLOG2TWITTER_WORKS", "It Works!" );
define ( "TRANSLATION_BLOG2TWITTER_STATUS", "blog2twitter Status" );